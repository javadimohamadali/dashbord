import './Table.css'
import TableUsers from '../../components/Tables/TableUsers/TableUsers'



export default function Table() {
  return (
    <div>
      <TableUsers />
    </div>
  )
}
