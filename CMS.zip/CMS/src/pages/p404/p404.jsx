import './p404.css'

export default function p404() {
  return (
    <div className='p404 fs-1 w-100 h-100 textalign-center'>p404</div>
  )
}
